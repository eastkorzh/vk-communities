self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cf946c3a98d74846be39b2aa9106626a",
    "url": "/index.html"
  },
  {
    "revision": "976dccb2bf32256d1f40",
    "url": "/static/css/main.6b415653.chunk.css"
  },
  {
    "revision": "1729f9ec0d1e1f9e5d1f",
    "url": "/static/js/2.8dd9855f.chunk.js"
  },
  {
    "revision": "976dccb2bf32256d1f40",
    "url": "/static/js/main.e6ff3120.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "d88ec05ccc640cb2ef0adc6098bf27b3",
    "url": "/static/media/back_24.d88ec05c.svg"
  },
  {
    "revision": "e69d0c97c1aeb836081d95009a6b995d",
    "url": "/static/media/comment_outline_24.e69d0c97.svg"
  },
  {
    "revision": "d6f67df9b1a42e09656e0574a483d240",
    "url": "/static/media/like_16.d6f67df9.svg"
  },
  {
    "revision": "37bcdecdb5e1c9f9f16a7869f47b655a",
    "url": "/static/media/like_outline_24.37bcdecd.svg"
  },
  {
    "revision": "06ac0036d081a135f56486279de7cb03",
    "url": "/static/media/share_outline_24.06ac0036.svg"
  },
  {
    "revision": "7d449b6246cea61f3fd25a5d34099731",
    "url": "/static/media/view_24.7d449b62.svg"
  }
]);